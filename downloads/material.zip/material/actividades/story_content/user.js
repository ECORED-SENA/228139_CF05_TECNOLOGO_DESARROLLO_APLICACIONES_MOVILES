function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ZVgdazTvNT":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

